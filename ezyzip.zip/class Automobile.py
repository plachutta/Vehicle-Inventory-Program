class Automobile:
    def __init__(self, make, model, color, year, mileage):
        """
        Constructor to initialize an Automobile object with given attributes.
        """
        self._make = make
        self._model = model
        self._color = color
        self._year = year
        self._mileage = mileage

    def display_details(self):
        """
        Display details of the automobile.
        """
        print(f"\nMake: {self._make}")
        print(f"Model: {self._model}")
        print(f"Color: {self._color}")
        print(f"Year: {self._year}")
        print(f"Mileage: {self._mileage} miles")

    def update_attributes(self, make=None, model=None, color=None, year=None, mileage=None):
        """
        Update attributes of the automobile.
        """
        if make:
            self._make = make
        if model:
            self._model = model
        if color:
            self._color = color
        if year:
            self._year = year
        if mileage:
            self._mileage = mileage

# Pre-populated list of automobile models
available_models = {
    "Toyota": ["Camry", "Corolla", "Rav4"],
    "Honda": ["Accord", "Civic", "CR-V"],
    "Ford": ["Fusion", "Escape", "Mustang"]
}

# Inventory to store Automobile objects
inventory = []

def add_vehicle():
    """
    Add a new vehicle to the inventory.
    """
    print("\nAvailable Car Models:")
    for make, models in available_models.items():
        print(f"{make}: {', '.join(models)}")

    make = input("\nEnter the make of the vehicle: ")
    
    # Allow the user to add a new model if it doesn't exist
    if make not in available_models:
        add_new_model(make)
    
    print(f"Available models for {make}: {', '.join(available_models[make])}")
    model = input("Enter the model of the vehicle: ")

    color = input("Enter the color of the vehicle: ")
    year = int(input("Enter the year of the vehicle: "))
    mileage = int(input("Enter the mileage of the vehicle: "))

    new_vehicle = Automobile(make, model, color, year, mileage)
    inventory.append(new_vehicle)
    print("Vehicle added successfully!")

def add_new_model(make):
    """
    Allow the user to add a new model to the available models.
    """
    new_model = input(f"\n{make} is not in the available models. Enter a new model: ")
    available_models.setdefault(make, []).append(new_model)
    print(f"New model '{new_model}' added to {make}.")

def remove_vehicle():
    """
    Remove a vehicle from the inventory.
    """
    make_to_remove = input("Enter the make of the vehicle to remove: ")
    model_to_remove = input("Enter the model of the vehicle to remove: ")

    for vehicle in inventory:
        if vehicle._make.lower() == make_to_remove.lower() and vehicle._model.lower() == model_to_remove.lower():
            inventory.remove(vehicle)
            print("Vehicle removed successfully!")
            return

    print("Vehicle not found in the inventory.")

def update_vehicle():
    """
    Update attributes of a vehicle in the inventory.
    """
    make_to_update = input("Enter the make of the vehicle to update: ")
    model_to_update = input("Enter the model of the vehicle to update: ")

    for vehicle in inventory:
        if vehicle._make.lower() == make_to_update.lower() and vehicle._model.lower() == model_to_update.lower():
            print("\nEnter new details:")
            make = input("Make (Press Enter to keep the current value): ")
            model = input("Model (Press Enter to keep the current value): ")
            color = input("Color (Press Enter to keep the current value): ")
            year = int(input("Year (Press Enter to keep the current value): "))
            mileage = int(input("Mileage (Press Enter to keep the current value): "))

            vehicle.update_attributes(make, model, color, year, mileage)
            print("Vehicle details updated successfully!")
            return

    print("Vehicle not found in the inventory.")

def display_inventory():
    """
    Display details of all vehicles in the inventory.
    """
    if not inventory:
        print("Inventory is empty.")
    else:
        for vehicle in inventory:
            vehicle.display_details()

def save_to_text_file():
    """
    Save vehicle inventory details to a text file.
    """
    file_name = input("Enter the filename to save the inventory (include .txt extension): ")
    with open(file_name, 'w') as file:
        for vehicle in inventory:
            file.write(f"\n{'='*20}\n")
            file.write(f"Make: {vehicle._make}\n")
            file.write(f"Model: {vehicle._model}\n")
            file.write(f"Color: {vehicle._color}\n")
            file.write(f"Year: {vehicle._year}\n")
            file.write(f"Mileage: {vehicle._mileage} miles\n")

def main():
    while True:
        print("\n--- Automobile Inventory Program ---")
        print("1. Add Vehicle\n2. Remove Vehicle\n3. Update Vehicle\n4. Display Inventory\n5. Save to Text File\n6. Exit")
        choice = input("Enter your choice (1-6): ")

        if choice == '1':
            add_vehicle()
        elif choice == '2':
            remove_vehicle()
        elif choice == '3':
            update_vehicle()
        elif choice == '4':
            display_inventory()
        elif choice == '5':
            save_to_text_file()
        elif choice == '6':
            break
        else:
            print("Invalid choice. Please enter a valid option.")

if __name__ == "__main__":
    main()